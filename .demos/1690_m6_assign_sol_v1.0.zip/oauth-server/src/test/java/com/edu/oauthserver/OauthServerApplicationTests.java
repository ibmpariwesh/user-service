package com.edu.oauthserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
