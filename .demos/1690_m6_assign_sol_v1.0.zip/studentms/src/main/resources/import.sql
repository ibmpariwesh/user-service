insert into student (name, date_of_birth) values ('John Doe', '1991-01-01');
insert into student (name, date_of_birth) values ('Jane Doe', '1992-02-02');