package com.edu.studentms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
